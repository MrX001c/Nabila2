Line Etot JS
`Version : 0.2.1`

# require node >= v8.x.x
check your nodejs version
`node -v`
[upgrade nodejs](https://google.com/)


How to run ?
------
- `git clone https://github.com/rivaimunte/LineEtotJS.git`
- `cd LineEtotJS && npm install`
- `npm start`

New
-------
- Penampilan Script
- Add Contact By Command
- CekId By Command (Bukan Myid)
- Broadcast Group
- Create Group By Command

Note
-------
- Jangan Perjual Belikan Script Ini!
- Ini Alphat Lama Tapi Di Upgrade
- Gunakan Script Ini Dengan Bijak!
- Mohon Maaf Ban,Unban,Banlist Di Skip Dulu :(

Still work :construction_worker:
----
**TODO** features
- Implement All 
- Improve logic

Author
------
[@rivaimunte](http://line.me/ti/p/~kobe2k17)
